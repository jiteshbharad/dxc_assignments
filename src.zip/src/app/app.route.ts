import { LoginComponent } from "./login/login.component";
import { HomeComponent } from "./home/home.component";
import { AuthGuard } from "./auth.guard";
import { Routes } from "@angular/router";
import { AddStudentComponent } from "./add-student/add-student.component";

export const routes:Routes =[
    {path:'login',component:LoginComponent},
    {path:'',redirectTo:'login',pathMatch:'full'},
    {path:'home',component:HomeComponent,canActivate:[AuthGuard]},
    {path:'signup',component:AddStudentComponent}
];