import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { StudentService } from './student.service';
import { HttpModule } from '@angular/http';
import { AddStudentComponent } from './add-student/add-student.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RouterModule } from '@angular/router';
import {routes} from './app.route';
import { AuthService } from './auth.service';
import { CookieService } from 'ngx-cookie-service';
import { AuthGuard } from './auth.guard';

@NgModule({
  declarations: [
    AppComponent,
    AddStudentComponent,
    LoginComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    RouterModule.forRoot(routes),
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [StudentService,AuthService,CookieService,AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
