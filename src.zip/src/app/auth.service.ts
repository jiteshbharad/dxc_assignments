import {Injectable} from '@angular/core'
import { Http } from '@angular/http';
import {CookieService} from 'ngx-cookie-service';
import { ifStmt } from '@angular/compiler/src/output/output_ast';
import { map, retry } from 'rxjs/operators';

@Injectable()

export class AuthService
{
    response={};

    constructor(private _http:Http,private cookie:CookieService)
    {

    }    
 
    public login(username,password)
    {
        let url="http://localhost:8081/restjsondemo/webapi/myresource/login";
        let body={};
        body["username"]=username;
        body["password"]=password;
       return this._http.post(url,body)
    }

    public getLoggedUser()
    {
        if(this.cookie.get("username"))
           return this.cookie.get("username");
        return null;
    }
}