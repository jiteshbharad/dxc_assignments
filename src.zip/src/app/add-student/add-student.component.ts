import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl}from '@angular/forms';
import { StudentService } from '../student.service';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {
  std_response:any;
  studentform=new FormGroup({
    name:new FormControl(''),
    password:new FormControl(''),
    rollno:new FormControl(''),
    marks:new FormControl(''),
    dept:new FormControl('')
  });
  constructor(private studentservice:StudentService,private router:Router,private cookie:CookieService) { }

  ngOnInit() {
      
  }
  loadOnServer()
  {
    this.studentservice.addStudent(this.studentform.value)
                       .subscribe(
                        resp=>this.std_response=resp.json(),
                        err=>this.std_response=err,
                        ()=>this.processAfterSignup(this.std_response)
                        );
  }

  processAfterSignup(response)
  {
    alert("Added successfully");
    this.cookie.set("username",this.studentform.value.username);
    this.cookie.set("password",this.studentform.value.password);
    this.router.navigate(['home']);
  }
}
