import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup} from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login_resp:any;

  loginform=new FormGroup({
    uname:new FormControl(''),
    password:new FormControl(''),
  });

  constructor(private authservice:AuthService,private router:Router,private cookie:CookieService) { }

  ngOnInit() {
  }

  private login()
  {
    this.authservice.login(this.loginform.value.uname,this.loginform.value.password)
                    .subscribe(
                      resp=>this.login_resp=resp.json(),
                      err=>this.login_resp=err,
                      ()=>this.processAfterLogin(this.login_resp)
                      );
  }

  processAfterLogin(resp)
  {
    console.log("response status "+resp['status']);
    if(resp['status']==0)
    {
      this.cookie.set("username",this.loginform.value.uname);
      this.cookie.set("password",this.loginform.value.password);
      this.router.navigate(['home']);
    }
    else
    {
      alert('Invalid username/password');
    }
  }
}
