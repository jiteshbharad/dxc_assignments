import { Injectable } from "@angular/core";
import {Http} from '@angular/http';
import { Headers } from '@angular/http';

@Injectable()

export class StudentService{

    url="http://localhost:8081/restjsondemo/webapi/myresource/";
    constructor(private _http:Http)
    {

    }

    getDetails(username,password)
    {
        let url=this.url+'secured/details/'+username;
        let header=new Headers({'Content-Type': 'Application/Json'});
        let auth_prefix="Basic ";
        let cred=username+":"+password;
        cred=btoa(cred);
        let auth_value= auth_prefix+cred;
        header.append("Authorization",auth_value);
        return this._http.get(url,{headers:header});
    }

    addStudent(std:any)
    {
        let name=std.name;
        let rollno=std.rollno;
        let marks=std.marks;
        let dept=std.dept;
        let password=std.password;
  
       let body={};
       body['name']=name;
       body['password']=password;
       body['rollno']=rollno;
       body['marks']=marks;
       body["dept"]=dept;
        
       let header=new Headers({'Content-Type': 'Application/Json'});
       console.log("adding student");
       return this._http.post(this.url+"signup",body,{headers:header}); 
    }

} 