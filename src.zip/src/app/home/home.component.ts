import { Component, OnInit } from '@angular/core';
import {CookieService} from 'ngx-cookie-service';
import { Router } from '@angular/router';
import { StudentService } from '../student.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  details:any;
  constructor(private cookieService:CookieService,private router:Router,private student_service:StudentService) {
   }

  ngOnInit() {
  }
 
  logout()
  {
    alert('Are you sure');
    this.cookieService.delete('username');
    this.router.navigate(['login']);
  }

  getDetails()
  {
    let username=this.cookieService.get("username");
    let password=this.cookieService.get("password");
    this.student_service.getDetails(username,password)
    .subscribe(
      resp=>this.details=resp.json(),
      err=>this.details=err,
      ()=>this.postLoad(this.details)
      );
  }

  postLoad(details)
  {
    console.log("detaisl"+details.message);
  }

}
